import { exec } from "child_process"
import { promisify } from "util"
import fs from "fs/promises"
import path from "path"
import os from "os"
import { logger } from "../utils/logger.js"

const execAsync = promisify(exec)

export class ToolManager {
  constructor() {
    this.tools = {
      run_command: this.runCommand.bind(this),
      read_file: this.readFile.bind(this),
      write_file: this.writeFile.bind(this),
      fix_errors: this.fixErrors.bind(this),
      get_system_info: this.getSystemInfo.bind(this),
      create_directory: this.createDirectory.bind(this),
      list_directory: this.listDirectory.bind(this),
      delete_file: this.deleteFile.bind(this),
      analyze_project: this.analyzeProject.bind(this),
    }
  }

  async execute(toolName, input) {
    if (!this.tools[toolName]) {
      throw new Error(`Tool ${toolName} not found`)
    }

    try {
      const result = await this.tools[toolName](input)
      return { success: true, result }
    } catch (error) {
      logger.error(`Tool ${toolName} failed:`, error.message)
      return { success: false, error: error.message }
    }
  }

  async runCommand(command) {
    logger.info(`Executing command: ${command}`)

    try {
      const { stdout, stderr } = await execAsync(command, {
        timeout: 30000, // 30 second timeout
        maxBuffer: 1024 * 1024, // 1MB buffer
      })

      const output = stdout || stderr
      return `✅ Command executed successfully:\n${output}`
    } catch (error) {
      return `❌ Command failed: ${error.message}`
    }
  }

  async readFile(filePath) {
    try {
      const content = await fs.readFile(filePath, "utf-8")
      return `📖 File content of ${filePath}:\n${content}`
    } catch (error) {
      return `❌ Failed to read file ${filePath}: ${error.message}`
    }
  }

  async writeFile({ path: filePath, content }) {
    try {
      // Ensure directory exists
      const dir = path.dirname(filePath)
      await fs.mkdir(dir, { recursive: true })

      await fs.writeFile(filePath, content, "utf-8")
      return `📝 Successfully wrote to ${filePath}`
    } catch (error) {
      return `❌ Failed to write file ${filePath}: ${error.message}`
    }
  }

  async createDirectory(dirPath) {
    try {
      await fs.mkdir(dirPath, { recursive: true })
      return `📁 Directory created: ${dirPath}`
    } catch (error) {
      return `❌ Failed to create directory ${dirPath}: ${error.message}`
    }
  }

  async listDirectory(dirPath = ".") {
    try {
      const files = await fs.readdir(dirPath, { withFileTypes: true })
      const fileList = files
        .map((file) => {
          const type = file.isDirectory() ? "📁" : "📄"
          return `${type} ${file.name}`
        })
        .join("\n")

      return `📋 Directory listing for ${dirPath}:\n${fileList}`
    } catch (error) {
      return `❌ Failed to list directory ${dirPath}: ${error.message}`
    }
  }

  async deleteFile(filePath) {
    try {
      await fs.unlink(filePath)
      return `🗑️ File deleted: ${filePath}`
    } catch (error) {
      return `❌ Failed to delete file ${filePath}: ${error.message}`
    }
  }

  async analyzeProject(projectPath = ".") {
    try {
      const packageJsonPath = path.join(projectPath, "package.json")
      let projectInfo = { type: "unknown", dependencies: [] }

      try {
        const packageJson = JSON.parse(await fs.readFile(packageJsonPath, "utf-8"))
        projectInfo = {
          type: "node",
          name: packageJson.name,
          dependencies: Object.keys(packageJson.dependencies || {}),
          devDependencies: Object.keys(packageJson.devDependencies || {}),
          scripts: Object.keys(packageJson.scripts || {}),
        }
      } catch {
        // Not a Node.js project, check for other indicators
        const files = await fs.readdir(projectPath)
        if (files.includes("requirements.txt")) {
          projectInfo.type = "python"
        } else if (files.includes("index.html")) {
          projectInfo.type = "web"
        }
      }

      return `🔍 Project analysis:\n${JSON.stringify(projectInfo, null, 2)}`
    } catch (error) {
      return `❌ Failed to analyze project: ${error.message}`
    }
  }

  getSystemInfo() {
    const platform = os.platform()
    const arch = os.arch()
    const release = os.release()
    const totalMem = Math.round(os.totalmem() / 1024 / 1024 / 1024)

    return `💻 System Info:
Platform: ${platform}
Architecture: ${arch}
Release: ${release}
Memory: ${totalMem}GB`
  }

  fixErrors(errorLog) {
    const suggestions = []

    if (errorLog.includes("ModuleNotFoundError") || errorLog.includes("Cannot find module")) {
      suggestions.push("📦 Install missing dependencies with npm install or pip install")
    }

    if (errorLog.includes("SyntaxError")) {
      suggestions.push("🔧 Check for syntax errors: missing brackets, semicolons, or typos")
    }

    if (errorLog.includes("EADDRINUSE") || errorLog.includes("port is already in use")) {
      suggestions.push("🔌 Port is in use. Try a different port or kill the process")
    }

    if (errorLog.includes("ENOENT")) {
      suggestions.push("📁 File or directory not found. Check paths and permissions")
    }

    if (errorLog.includes("permission denied") || errorLog.includes("EACCES")) {
      suggestions.push("🔐 Permission denied. Try running with sudo or check file permissions")
    }

    if (suggestions.length === 0) {
      suggestions.push("🤔 No specific fix found. Please review the error manually")
    }

    return `🛠️ Error Analysis & Suggestions:\n${suggestions.join("\n")}`
  }
}
