import OpenAI from "openai"
import { logger } from "../utils/logger.js"

export class AIProviderManager {
  constructor() {
    this.providers = {
      gemini: this.createGeminiClient(),
      mistral: this.createMistralClient(),
      deepseek: this.createDeepSeekClient(),
    }
  }

  createGeminiClient() {
    return new OpenAI({
      apiKey: process.env.GEMINI_API_KEY,
      baseURL: "https://generativelanguage.googleapis.com/v1beta/openai/",
    })
  }

  createMistralClient() {
    return new OpenAI({
      apiKey: process.env.MISTRAL_API_KEY,
      baseURL: "https://api.mistral.ai/v1",
    })
  }

  createDeepSeekClient() {
    return new OpenAI({
      apiKey: process.env.DEEPSEEK_API_KEY,
      baseURL: "https://api.deepseek.com/v1",
    })
  }

  async generateResponse(provider, messages) {
    const client = this.providers[provider]
    if (!client) {
      throw new Error(`Provider ${provider} not found`)
    }

    try {
      const modelMap = {
        gemini: "gemini-2.0-flash",
        mistral: "mistral-large-latest",
        deepseek: "deepseek-chat",
      }

      const response = await client.chat.completions.create({
        model: modelMap[provider],
        messages: messages,
        response_format: { type: "json_object" },
        temperature: 0.1,
        max_tokens: 4000,
      })

      return response.choices[0].message.content
    } catch (error) {
      logger.error(`Error with ${provider} provider:`, error.message)
      throw error
    }
  }
}
