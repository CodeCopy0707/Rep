import { AIProviderManager } from "./providers.js"
import { ToolManager } from "./tools.js"
import { ConversationManager } from "./conversation.js"
import { StepExecutor } from "./executor.js"
import { logger } from "../utils/logger.js"
import { getUserInput } from "../utils/input.js"
import chalk from "chalk"

export class AIAgent {
  constructor() {
    this.providerManager = new AIProviderManager()
    this.toolManager = new ToolManager()
    this.conversationManager = new ConversationManager()
    this.stepExecutor = new StepExecutor(this.toolManager)
    this.currentProvider = "gemini" // default
  }

  async start() {
    logger.info("🚀 AI Coding Agent initialized")

    // Select AI provider
    await this.selectProvider()

    // Main interaction loop
    while (true) {
      try {
        const userQuery = await getUserInput("> ")

        if (userQuery.toLowerCase() === "exit" || userQuery.toLowerCase() === "quit") {
          break
        }

        if (userQuery.toLowerCase().startsWith("switch ")) {
          const provider = userQuery.split(" ")[1]
          await this.switchProvider(provider)
          continue
        }

        await this.processQuery(userQuery)
      } catch (error) {
        logger.error("Error processing query:", error.message)
      }
    }
  }

  async selectProvider() {
    console.log(chalk.blue("Available AI Providers:"))
    console.log("1. Gemini (Google)")
    console.log("2. Mistral AI")
    console.log("3. DeepSeek AI")

    const choice = await getUserInput("Select provider (1-3) or press Enter for Gemini: ")

    switch (choice.trim()) {
      case "2":
        this.currentProvider = "mistral"
        break
      case "3":
        this.currentProvider = "deepseek"
        break
      default:
        this.currentProvider = "gemini"
    }

    logger.info(`Selected provider: ${this.currentProvider}`)
  }

  async switchProvider(provider) {
    const validProviders = ["gemini", "mistral", "deepseek"]
    if (validProviders.includes(provider.toLowerCase())) {
      this.currentProvider = provider.toLowerCase()
      logger.info(`Switched to provider: ${this.currentProvider}`)
    } else {
      logger.error(`Invalid provider. Available: ${validProviders.join(", ")}`)
    }
  }

  async processQuery(userQuery) {
    // Add user query to conversation
    this.conversationManager.addMessage("user", userQuery)

    let step = "start"
    const maxIterations = 20 // Prevent infinite loops
    let iteration = 0

    while (step !== "output" && iteration < maxIterations) {
      iteration++

      try {
        // Get AI response for current step
        const response = await this.getAIResponse()

        if (!response) {
          logger.error("No response from AI provider")
          break
        }

        // Parse and validate response
        const parsedResponse = this.parseResponse(response)
        if (!parsedResponse) {
          logger.error("Invalid response format from AI")
          break
        }

        // Execute the step
        const result = await this.stepExecutor.execute(parsedResponse)

        // Update conversation with AI response and results
        this.conversationManager.addMessage("assistant", JSON.stringify(parsedResponse))

        if (result && result.observation) {
          this.conversationManager.addMessage(
            "assistant",
            JSON.stringify({
              step: "observe",
              content: result.observation,
            }),
          )
        }

        step = parsedResponse.step

        // Provide status update
        this.provideStatusUpdate(parsedResponse, result)
      } catch (error) {
        logger.error(`Error in iteration ${iteration}:`, error.message)
        break
      }
    }

    if (iteration >= maxIterations) {
      logger.warn("Maximum iterations reached. Task may be incomplete.")
    }
  }

  async getAIResponse() {
    const messages = this.conversationManager.getMessages()
    return await this.providerManager.generateResponse(this.currentProvider, messages)
  }

  parseResponse(response) {
    try {
      return JSON.parse(response)
    } catch (error) {
      logger.error("Failed to parse AI response:", error.message)
      return null
    }
  }

  provideStatusUpdate(parsedResponse, result) {
    const step = parsedResponse.step

    switch (step) {
      case "start":
        console.log(chalk.blue("🎯 Starting task analysis..."))
        break
      case "plan":
        console.log(chalk.yellow("📋 Planning:"), parsedResponse.content)
        break
      case "action":
        console.log(chalk.green("⚡ Executing:"), parsedResponse.function)
        if (result && result.success) {
          console.log(chalk.green("✅ Success"))
        } else if (result && !result.success) {
          console.log(chalk.red("❌ Failed:"), result.error)
        }
        break
      case "observe":
        console.log(chalk.cyan("👁️  Analyzing results..."))
        break
      case "output":
        console.log(chalk.magenta("🎉 Task completed:"), parsedResponse.content)
        break
    }
  }
}
