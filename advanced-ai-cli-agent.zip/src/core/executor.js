import { logger } from "../utils/logger.js"
import chalk from "chalk"

export class StepExecutor {
  constructor(toolManager) {
    this.toolManager = toolManager
  }

  async execute(parsedResponse) {
    const { step, function: functionName, input, content } = parsedResponse

    switch (step) {
      case "start":
        return this.handleStart(content)

      case "plan":
        return this.handlePlan(content)

      case "action":
        return await this.handleAction(functionName, input)

      case "observe":
        return this.handleObserve(content)

      case "output":
        return this.handleOutput(content)

      default:
        logger.warn(`Unknown step: ${step}`)
        return { success: false, error: `Unknown step: ${step}` }
    }
  }

  handleStart(content) {
    console.log(chalk.blue("🎯 Task Analysis:"), content)
    return { success: true }
  }

  handlePlan(content) {
    console.log(chalk.yellow("📋 Execution Plan:"))
    console.log(content)
    return { success: true }
  }

  async handleAction(functionName, input) {
    if (!functionName) {
      return { success: false, error: "No function specified for action" }
    }

    console.log(chalk.green(`⚡ Executing: ${functionName}`))

    try {
      const result = await this.toolManager.execute(functionName, input)

      if (result.success) {
        console.log(chalk.green("✅ Action completed"))
        if (result.result) {
          console.log(result.result)
        }
        return {
          success: true,
          observation: result.result || "Action completed successfully",
        }
      } else {
        console.log(chalk.red("❌ Action failed:"), result.error)
        return {
          success: false,
          error: result.error,
          observation: `Action failed: ${result.error}`,
        }
      }
    } catch (error) {
      console.log(chalk.red("❌ Execution error:"), error.message)
      return {
        success: false,
        error: error.message,
        observation: `Execution error: ${error.message}`,
      }
    }
  }

  handleObserve(content) {
    console.log(chalk.cyan("👁️  Observation:"), content)
    return { success: true }
  }

  handleOutput(content) {
    console.log(chalk.magenta("🎉 Final Result:"))
    console.log(content)
    return { success: true, final: true }
  }
}
