import { getSystemPrompt } from "../prompts/system.js"

export class ConversationManager {
  constructor() {
    this.messages = [{ role: "system", content: getSystemPrompt() }]
  }

  addMessage(role, content) {
    this.messages.push({ role, content })
  }

  getMessages() {
    return [...this.messages]
  }

  clearHistory() {
    this.messages = [{ role: "system", content: getSystemPrompt() }]
  }

  getLastUserMessage() {
    for (let i = this.messages.length - 1; i >= 0; i--) {
      if (this.messages[i].role === "user") {
        return this.messages[i].content
      }
    }
    return null
  }
}
