#!/usr/bin/env node

import { AIAgent } from "./core/agent.js"
import { setupEnvironment } from "./utils/setup.js"
import { logger } from "./utils/logger.js"
import chalk from "chalk"

async function main() {
  console.log(chalk.cyan.bold("🤖 Advanced AI CLI Coding Agent"))
  console.log(chalk.gray("Supporting Gemini, Mistral, and DeepSeek AI\n"))

  try {
    // Setup environment and validate API keys
    await setupEnvironment()

    // Initialize the AI agent
    const agent = new AIAgent()

    // Start interactive session
    await agent.start()
  } catch (error) {
    logger.error("Failed to initialize AI Agent:", error.message)
    process.exit(1)
  }
}

// Handle graceful shutdown
process.on("SIGINT", () => {
  console.log(chalk.yellow("\n👋 Goodbye! AI Agent shutting down..."))
  process.exit(0)
})

process.on("uncaughtException", (error) => {
  logger.error("Uncaught Exception:", error)
  process.exit(1)
})

main().catch(console.error)
