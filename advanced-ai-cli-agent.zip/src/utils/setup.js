import fs from "fs/promises"
import { logger } from "./logger.js"
import chalk from "chalk"

export async function setupEnvironment() {
  // Check for .env file
  try {
    await fs.access(".env")

    // Load environment variables
    const { config } = await import("dotenv")
    config()
  } catch (error) {
    // Create .env template if it doesn't exist
    await createEnvTemplate()
  }

  // Validate API keys
  validateApiKeys()
}

async function createEnvTemplate() {
  const envTemplate = `# AI Provider API Keys
# Get your API keys from:
# Gemini: https://makersuite.google.com/app/apikey
# Mistral: https://console.mistral.ai/
# DeepSeek: https://platform.deepseek.com/

GEMINI_API_KEY=your_gemini_api_key_here
MISTRAL_API_KEY=your_mistral_api_key_here
DEEPSEEK_API_KEY=your_deepseek_api_key_here
`

  try {
    await fs.writeFile(".env", envTemplate)
    console.log(chalk.yellow("📝 Created .env template file"))
    console.log(chalk.yellow("Please add your API keys to the .env file"))
  } catch (error) {
    logger.error("Failed to create .env template:", error.message)
  }
}

function validateApiKeys() {
  const requiredKeys = ["GEMINI_API_KEY", "MISTRAL_API_KEY", "DEEPSEEK_API_KEY"]
  const missingKeys = []

  for (const key of requiredKeys) {
    if (!process.env[key] || process.env[key].includes("your_") || process.env[key].includes("_here")) {
      missingKeys.push(key)
    }
  }

  if (missingKeys.length > 0) {
    console.log(chalk.yellow("⚠️  Missing or invalid API keys:"))
    missingKeys.forEach((key) => console.log(chalk.yellow(`   - ${key}`)))
    console.log(chalk.yellow("Please update your .env file with valid API keys"))
    console.log(chalk.gray("The agent will still work with available providers\n"))
  } else {
    console.log(chalk.green("✅ All API keys configured\n"))
  }
}
