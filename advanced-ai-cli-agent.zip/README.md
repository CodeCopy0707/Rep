# Advanced AI CLI Coding Agent

A sophisticated Node.js-based AI coding agent that supports multiple AI providers (Gemini, Mistral, and DeepSeek AI) and follows an iterative execute → analyze → plan → execute workflow.

## Features

- 🤖 **Multi-Provider Support**: Gemini, Mistral AI, and DeepSeek AI
- ⚡ **Step-by-Step Execution**: Execute one action at a time with thorough analysis
- 🔍 **Result Analysis**: Carefully examine outputs and errors after each step
- 📋 **Adaptive Planning**: Plan next steps based on current results
- ✅ **Requirement Validation**: Ensure progress aligns with user requirements
- 📊 **Clear Status Updates**: Detailed progress communication
- 🛠️ **Comprehensive Tools**: File operations, command execution, error analysis
- 🎯 **Project Management**: Automatic project structure creation and analysis

## Installation

1. Clone or download the project
2. Install dependencies:
   \`\`\`bash
   npm install
   \`\`\`

3. Set up your API keys in `.env` file:
   \`\`\`env
   GEMINI_API_KEY=your_gemini_api_key_here
   MISTRAL_API_KEY=your_mistral_api_key_here
   DEEPSEEK_API_KEY=your_deepseek_api_key_here
   \`\`\`

## Usage

Start the AI agent:
\`\`\`bash
npm start
\`\`\`

### Commands

- Type your coding request and the agent will break it down into steps
- `switch gemini|mistral|deepseek` - Switch AI provider
- `exit` or `quit` - Exit the agent

### Example Interactions

\`\`\`
> Create a React TypeScript app with Tailwind CSS
🎯 Starting task analysis...
📋 Planning: 1. Create project folder 2. Initialize React app 3. Add TypeScript 4. Install Tailwind...
⚡ Executing: create_directory
✅ Success
...
\`\`\`

## Available Tools

- **run_command**: Execute shell commands
- **read_file**: Read file contents
- **write_file**: Create/modify files
- **create_directory**: Create directories
- **list_directory**: List directory contents
- **delete_file**: Remove files
- **analyze_project**: Analyze project structure
- **get_system_info**: Get system information
- **fix_errors**: Analyze and suggest error fixes

## AI Providers

### Gemini (Google)
- Get API key: https://makersuite.google.com/app/apikey
- Model: gemini-2.0-flash

### Mistral AI
- Get API key: https://console.mistral.ai/
- Model: mistral-large-latest

### DeepSeek AI
- Get API key: https://platform.deepseek.com/
- Model: deepseek-chat

## Architecture

- **Core Agent**: Main orchestration and conversation management
- **Provider Manager**: Multi-AI provider support
- **Tool Manager**: Comprehensive development tools
- **Step Executor**: Iterative execution with analysis
- **Conversation Manager**: Context and history management

## Development

Run in development mode with auto-reload:
\`\`\`bash
npm run dev
\`\`\`

## License

MIT License
